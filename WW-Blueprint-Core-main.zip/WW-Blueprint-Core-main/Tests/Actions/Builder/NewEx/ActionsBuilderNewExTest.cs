namespace BlueprintCore.Test.Actions.Builder.NewEx
{
  public class ActionsBuilderNewExTest : TestBase { }
}
