﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Blueprint-Core-Test")]
