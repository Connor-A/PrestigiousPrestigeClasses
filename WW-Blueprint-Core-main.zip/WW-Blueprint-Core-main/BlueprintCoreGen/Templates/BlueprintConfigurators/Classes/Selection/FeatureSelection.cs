using BlueprintCore.Utils;
using Kingmaker.Blueprints;
using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Classes.Selection;
using System.Linq;

namespace BlueprintCoreGen.Blueprints.Configurators.Classes.Selection
{
  /// <summary>Configurator for <see cref="BlueprintFeatureSelection"/>.</summary>
  /// <inheritdoc/>
  [Configures(typeof(BlueprintFeatureSelection))]
  public class FeatureSelectionConfigurator
      : BaseFeatureConfigurator<BlueprintFeatureSelection, FeatureSelectionConfigurator>
  {
    private FeatureSelectionConfigurator(string name) : base(name) { }

    /// <inheritdoc cref="Buffs.BuffConfigurator.For(string)"/>
    public static FeatureSelectionConfigurator For(string name)
    {
      return new FeatureSelectionConfigurator(name);
    }

    /// <inheritdoc cref="Buffs.BuffConfigurator.New(string, string)"/>
    public static FeatureSelectionConfigurator New(string name, string guid)
    {
      BlueprintTool.Create<BlueprintFeatureSelection>(name, guid);
      return For(name);
    }

    /// <summary>
    /// Sets <see cref="BlueprintFeatureSelection.IgnorePrerequisites"/>
    /// </summary>
    public FeatureSelectionConfigurator SetIgnorePrerequisites(bool ignore = true)
    {
      return OnConfigureInternal(blueprint => blueprint.IgnorePrerequisites = ignore);
    }

    /// <summary>
    /// Sets <see cref="BlueprintFeatureSelection.Mode"/>
    /// </summary>
    public FeatureSelectionConfigurator SetMode(SelectionMode mode)
    {
      return OnConfigureInternal(blueprint => blueprint.Mode = mode);
    }

    /// <summary>
    /// Sets <see cref="BlueprintFeatureSelection.Group"/>
    /// </summary>
    public FeatureSelectionConfigurator SetPrimaryGroup(FeatureGroup group)
    {
      return OnConfigureInternal(blueprint => blueprint.Group = group);
    }

    /// <summary>
    /// Sets <see cref="BlueprintFeatureSelection.Group2"/>
    /// </summary>
    public FeatureSelectionConfigurator SetSecondaryGroup(FeatureGroup group)
    {
      return OnConfigureInternal(blueprint => blueprint.Group2 = group);
    }

    /// <summary>
    /// Sets <see cref="BlueprintFeatureSelection.m_AllFeatures"/>
    /// </summary>
    /// 
    /// <param name="features"><see cref="BlueprintFeature"/></param>
    public FeatureSelectionConfigurator SetFeatures(params string[] features)
    {
      return OnConfigureInternal(
          blueprint =>
              blueprint.m_AllFeatures =
                  features.Select(feature => BlueprintTool.GetRef<BlueprintFeatureReference>(feature)).ToArray());
    }

    /// <summary>
    /// Adds to <see cref="BlueprintFeatureSelection.m_AllFeatures"/>
    /// </summary>
    /// 
    /// <param name="features"><see cref="BlueprintFeature"/></param>
    public FeatureSelectionConfigurator AddToFeatures(params string[] features)
    {
      return OnConfigureInternal(
          blueprint =>
          {
            blueprint.m_AllFeatures =
                CommonTool.Append(
                    blueprint.m_AllFeatures,
                    features.Select(feature => BlueprintTool.GetRef<BlueprintFeatureReference>(feature)).ToArray());
          });
    }

    /// <summary>
    /// Removes from <see cref="BlueprintFeatureSelection.m_AllFeatures"/>
    /// </summary>
    /// 
    /// <param name="features"><see cref="BlueprintFeature"/></param>
    public FeatureSelectionConfigurator RemoveFromFeatures(params string[] features)
    {
      return OnConfigureInternal(
          blueprint =>
          {
            var featureRefs = features.Select(feature => BlueprintTool.GetRef<BlueprintFeatureReference>(feature));
            blueprint.m_AllFeatures = blueprint.m_AllFeatures.Except(featureRefs).ToArray();
          });
    }

    // [GenerateComponents]
  }
}