﻿copy-item .\BlueprintConfigurators\* ..\..\..\..\BlueprintCore\BlueprintCore\Blueprints\Configurators -force -recurse -verbose
copy-item .\ActionsBuilder\* ..\..\..\..\BlueprintCore\BlueprintCore\Actions\Builder -force -recurse -verbose
copy-item .\ConditionsBuilder\* ..\..\..\..\BlueprintCore\BlueprintCore\Conditions\Builder -force -recurse -verbose